<?php 
/*
Plugin Name: Industry Toolkit
Plugin URI: http://rrf.ikamal.me/wp/
Description: This Plugin only for Industry theme. 
Author: Kamal Hosen	
Version: 1.0
Author URI: http://ikamal.me/
*/




function industry_toolkit_include_files() {

	wp_enqueue_style( 'owl-carousel', plugins_url( '/assets/css/owl.carousel.css', __FILE__ ) );
	wp_enqueue_style( 'industry-toolkit', plugins_url( '/assets/css/industry-toolkit.css', __FILE__ ) );

    wp_enqueue_script( 'owl-carousel', plugins_url( '/assets/js/owl.carousel.js', __FILE__ ), array('jquery'), '2.21',  true );
    wp_enqueue_script( 'isotope', plugins_url( '/assets/js/isotope.pkgd.min.js', __FILE__ ), array('jquery'), '3.0.5',  true );
}
add_action( 'wp_enqueue_scripts', 'industry_toolkit_include_files' );


function industry_custom_post() {
    register_post_type( 'slide',
        array(
            'labels' => array(
                'name' => __( 'Sliders' ),
                'singular_name' => __( 'Slide' )
            ),
            'supports' => array('title', 'editor', 'thumbnail', 'page-attributes'),
            'public' => false,
            'show_ui' => true,
        )
    );
    register_post_type( 'project',
        array(
            'labels' => array(
                'name' => __( 'Projects' ),
                'singular_name' => __( 'Project' )
            ),
            'supports' => array('title', 'editor', 'thumbnail', 'page-attributes'),
            'public' => true,
            'show_ui' => true,
        )
    );
}

add_action( 'init', 'industry_custom_post' );


function industry_taxnomy() {
    register_taxonomy(
        'slide_cat',  
        'slide',                  
        array(
            'hierarchical'          => true,
            'label'                 => 'Slide Category',  
            'query_var'             => true,
            'show_admin_column'     => true,
            'rewrite'               => array(
                'slug'              => 'slide-category', 
                'with_front'    => true 
                )
            )
    );
    register_taxonomy(
        'project_cat',  
        'project',                  
        array(
            'hierarchical'          => true,
            'label'                 => 'Project Category',  
            'query_var'             => true,
            'show_admin_column'     => true,
            'rewrite'               => array(
                'slug'              => 'project-category', 
                'with_front'    => true 
                )
            )
    );
}
add_action( 'init', 'industry_taxnomy' );


function industry_slide_cat_list(){
    $slide_cats = get_terms('slide_cat');

    $slide_cat_options = array('' => 'All Categories');

    if($slide_cats){
        foreach ($slide_cats as $slide_cat) {
           $slide_cat_options[$slide_cat->term_id] = $slide_cat->name;
        }
        return $slide_cat_options;
    }
}


	include_once( 'industry-shortcodes.php');
	include_once ('industry-toolkit-kc-addons.php');









