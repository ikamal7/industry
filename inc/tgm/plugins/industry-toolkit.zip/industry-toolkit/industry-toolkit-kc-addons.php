<?php
 
add_action('init', 'industry_kc_addons', 99 );
 
function industry_kc_addons() {
 
	if (function_exists('kc_add_map')) 
	{ 
	    kc_add_map(
	        array(

	            'insdustry_section_title' => array(
	                'name' => 'Section Title',
	                'description' => __('Big section title box', 'KingComposer'),
	                'icon' => get_template_directory_uri(). '/assets/img/icon.png',
	                'category' => 'Industry',
	                'params' => array(
	                	'General' => array(
		                    array(
		                        'name' => 'title',
		                        'label' => 'Enter your section Title',
		                        'type' => 'text',
		                    ),
		                    array(
		                        'name' => 'sub_title',
		                        'label' => 'Your Sub Title',
		                        'type' => 'text',
		                        'description' => __('Enter your section sub title', 'KingComposer')
		                    ),
		                    array(
		                        'name' => 'desc',
		                        'label' => 'Description',
		                        'type' => 'textarea',
		                        'description' => __('Enter your section small description', 'KingComposer')
		                    ),
		                    array(
		                        'name' => 'align',
		                        'label' => 'Text align',
		                        'type' => 'select',  // USAGE SELECT TYPE
								'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'text-center' => 'Center',
									'text-left' => 'Left',
									'text-right' => 'Right',
								),
								'value'		=> 'text-center',
		                        'description' => __('', 'KingComposer')
		                    ),
		                    array(
		                        'name' => 'title_tags',
		                        'label' => 'Title Tag',
		                        'type' => 'select',  // USAGE SELECT TYPE
								'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'h1' => 'H1',
									'h2' => 'H2',
									'h3' => 'H3',
									'h4' => 'H4',
									'h5' => 'H5',
									'h6' => 'H6',
								),
								'value'		=> 'h2',
		                        'description' => __('', 'KingComposer')
		                    ),
	                	),
	                	'CSS'	=> array(

		                    array(
		                        'name' => 'custom_css',
		                        'type' => 'css',
		                    ),
	                	)
	                )
	            ),  // End of elemnt kc_icon 

	        )
	    ); // End add map
	    kc_add_map(
	        array(
	            'insdustry_service_box' => array(
	                'name' => 'Industry Service Box',
	                'description' => __('Industry Service Box for adding new service', 'KingComposer'),
	                'icon' => 'sl-paper-plane',
	                'category' => 'Industry',
	                'params' => array(
	                    array(
	                        'name' => 'icon_type',
	                        'label' => 'Select your icon type',
	                        'type' => 'select',
	                        'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'1' => 'Select Iconic Font',
									'2' => 'Upload icon',
								),
	                        'value'			=> 1,
	                    ),
	                    array(
	                        'name' => 'fa_icon',
	                        'label' => 'Select a icon',
	                        'type' => 'icon_picker',
	                        'description' => __('Choose a icon for service box', 'KingComposer'),
	                        'relation' => array(
						        'parent'    => 'icon_type',
						        'show_when' => '1'
						    )
	                    ),
	                    array(
	                        'name' => 'img_icon',
	                        'label' => 'Upload a icon',
	                        'type' => 'attach_image',
	                        'description' => __('Upload a icon for service box', 'KingComposer'),
	                        'relation' => array(
						        'parent'    => 'icon_type',
						        'show_when' => '2'
						    )
	                    ),
	                    array(
	                        'name' => 'title',
	                        'label' => 'Enter your section Title',
	                        'type' => 'text',
	                        'description' => __('Write a Title for service box', 'KingComposer')
	                    ),
	                    array(
	                        'name' => 'desc',
	                        'label' => 'Description',
	                        'type' => 'textarea',
	                        'description' => __('Enter your section small description', 'KingComposer')
	                    )
	                )
	            ),  // End of elemnt kc_icon 

	        )
	    ); // End add map
	    kc_add_map(
	        array(
	            'insdustry_service_box3' => array(
	                'name' => 'Industry Service Box 3',
	                'description' => __('Industry Service Box 3 for adding new service', 'KingComposer'),
	                'icon' => 'sl-paper-plane',
	                'category' => 'Industry',
	                'params' => array(
	                    array(
	                        'name' => 'icon_type',
	                        'label' => 'Select your icon type',
	                        'type' => 'select',
	                        'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'1' => 'Select Iconic Font',
									'2' => 'Upload icon',
								),
	                        'value'			=> 1,
	                    ),
	                    array(
	                        'name' => 'fa_icon',
	                        'label' => 'Select a icon',
	                        'type' => 'icon_picker',
	                        'description' => __('Choose a icon for service box', 'KingComposer'),
	                        'relation' => array(
						        'parent'    => 'icon_type',
						        'show_when' => '1'
						    )
	                    ),
	                    array(
	                        'name' => 'img_icon',
	                        'label' => 'Upload a icon',
	                        'type' => 'attach_image',
	                        'description' => __('Upload a icon for service box', 'KingComposer'),
	                        'relation' => array(
						        'parent'    => 'icon_type',
						        'show_when' => '2'
						    )
	                    ),
	                    array(
	                        'name' => 'title',
	                        'label' => 'Enter your section Title',
	                        'type' => 'text',
	                        'description' => __('Write a Title for service box', 'KingComposer')
	                    ),
	                    array(
	                        'name' => 'desc',
	                        'label' => 'Description',
	                        'type' => 'textarea',
	                        'description' => __('Enter your section small description', 'KingComposer')
	                    ),
	                    array(
	                        'name' => 'link',
	                        'label' => 'Link',
	                        'type' => 'link',
	                        'description' => '',
	                    )
	                )
	            ),  // End of elemnt kc_icon 

	        )
	    ); // End add map
	    kc_add_map(
	        array(

	            'insdustry_counter_box' => array(
	                'name' => 'Industry Counter Box',
	                'description' => __('Industry counter Box for adding new counter', 'KingComposer'),
	                'icon' => 'sl-paper-plane',
	                'category' => 'Industry',
	                'params' => array(
	                    array(
	                        'name' => 'icon_type',
	                        'label' => 'Select your icon type',
	                        'type' => 'select',
	                        'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'1' => 'Select Iconic Font',
									'2' => 'Upload icon',
								),
	                        'value'			=> 1,
	                    ),
	                    array(
	                        'name' => 'fa_icon',
	                        'label' => 'Select a icon',
	                        'type' => 'icon_picker',
	                        'description' => __('Choose a icon for service box', 'KingComposer'),
	                        'relation' => array(
						        'parent'    => 'icon_type',
						        'show_when' => '1'
						    )
	                    ),
	                    array(
	                        'name' => 'img_icon',
	                        'label' => 'Upload a icon',
	                        'type' => 'attach_image',
	                        'description' => __('Upload a icon for service box', 'KingComposer'),
	                        'relation' => array(
						        'parent'    => 'icon_type',
						        'show_when' => '2'
						    )
	                    ),
	                    array(
	                        'name' => 'title',
	                        'label' => 'Title',
	                        'type' => 'text',
	                        'description' => __('Write a Title for counter box', 'KingComposer')
	                    ),
	                    array(
	                        'name' => 'counter_number',
	                        'label' => 'Counter Number',
	                        'type' => 'text',
	                        'description' => __('Type your counter number', 'KingComposer')
	                    )
	                )
	            ),  // End of elemnt kc_icon 

	        )
	    ); // End add map
	    kc_add_map(
	        array(

	            'insdustry_service_box2' => array(
	                'name' => 'Industry Service Box 2 with link',
	                'description' => __('Industry Service Box for adding new services', 'KingComposer'),
	                'icon' => 'sl-paper-plane',
	                'category' => 'Industry',
	                'params' => array(
	                    array(
	                        'name' => 'img',
	                        'label' => 'Upload a image',
	                        'type' => 'attach_image',
	                        'description' => __('Upload a icon for service box', 'KingComposer'),
	                    ),
	                    array(
	                        'name' => 'title',
	                        'label' => 'Enter your section Title',
	                        'type' => 'text',
	                        'description' => __('Write a Title for service box', 'KingComposer')
	                    ),
	                    array(
	                        'name' => 'desc',
	                        'label' => 'Description',
	                        'type' => 'textarea',
	                        'description' => __('Enter your section small description', 'KingComposer')
	                    ),
	                    array(
	                        'name' => 'link',
	                        'label' => 'Link',
	                        'type' => 'link',
	                        'description' => '',
	                    )
	                )
	            ),  // End of elemnt kc_icon 

	        )
	    ); // End add map

	    kc_add_map(
	        array(

	            'insdustry_case_study' => array(
	                'name' => 'Industry Case study',
	                'description' => __('Industry Case study for adding new case study', 'KingComposer'),
	                'icon' => 'sl-paper-plane',
	                'category' => 'Industry',
	                'params' => array(
	                    array(
	                        'name' => 'img',
	                        'label' => 'Upload a image',
	                        'type' => 'attach_image',
	                        'description' => __('Upload a image for Case study', 'KingComposer'),
	                    ),
	                    array(
	                        'name' => 'title',
	                        'label' => 'Enter your Title',
	                        'type' => 'text',
	                        'description' => __('Write a Title for Case study', 'KingComposer')
	                    ),
	                    array(
	                        'name' => 'desc',
	                        'label' => 'Description',
	                        'type' => 'textarea',
	                        'description' => __('Enter your section small description', 'KingComposer')
	                    ),
	                    array(
	                        'name' => 'link',
	                        'label' => 'Link',
	                        'type' => 'link',
	                        'description' => '',
	                    )
	                )
	            ),  // End of elemnt kc_icon 

	        )
	    ); // End add map

	    kc_add_map(
	        array(

	            'industry_slides' => array(
	                'name' => 'Industry Slider',
	                'description' => __('Use this addon for displaying slider', 'KingComposer'),
	                'icon' => 'sl-paper-plane',
	                'category' => 'Industry',
	                'params' => array(
	                    array(
	                        'name' => 'count',
	                        'label' => 'Slider count',
	                        'type' => 'text',
	                        'value'			=> 3,
	                        'description' => '',
	                    ),
	                    array(
	                        'name' => 'category',
	                        'label' => 'Categories',
	                        'type' => 'select',
	                        'options' => industry_slide_cat_list(),
	                        'description' => '',
	                    ),
	                    array(
	                        'name' => 'loop',
	                        'label' => 'Loop',
	                        'type' => 'select',
	                        'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'true' => 'Yes',
									'false' => 'No',
								),
	                        'value'			=> 'true',
	                        'description' => '',
	                    ),
	                    array(
	                        'name' => 'autoplay',
	                        'label' => 'Autoplay',
	                        'type' => 'select',
	                        'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'true' => 'Yes',
									'false' => 'No',
								),
	                        'value'			=> 'true',
	                        'description' => 'Type time in mili seconds',
	                    ),
	                    array(
	                        'name' => 'autoplayTimeout',
	                        'label' => 'Auto play timeout',
	                        'type' => 'text',
	                        'value'			=> 5000,
	                        'description' => '',
	                        'relation' => array(
						        'parent'    => 'autoplay',
						        'show_when' => 'true'
						    )
	                    ),
	                    array(
	                        'name' => 'nav',
	                        'label' => 'Navigation',
	                        'type' => 'select',
	                        'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'true' => 'Yes',
									'false' => 'No',
								),
	                        'value'			=> 'true',
	                        'description' => '',
	                    ),
	                    array(
	                        'name' => 'dots',
	                        'label' => 'Dots',
	                        'type' => 'select',
	                        'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'true' => 'Yes',
									'false' => 'No',
								),
	                        'value'			=> 'true',
	                        'description' => '',
	                    ),
	                )
	            ),  // End of elemnt kc_icon 

	        )
	    ); // End add map
	
	} // End if

}  
 
