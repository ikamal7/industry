<?php 



//Section title shortcode register

function insdustry_section_title_shortcode($atts, $content = null){
	extract(shortcode_atts(  array(
		'title' => '', 
		'sub_title' => '', 
		'desc' => '',
		'align'	=> 'text-center',
		'title_tags' => 'h2'
	), $atts ));   
	$master_class = apply_filters( 'kc-el-class', $atts );


	$insdustry_section_title_markup = '<div class="insdustry_section_title '.$align.' '.implode(' ', $master_class).'">';

	if (!empty($sub_title)) {
		$insdustry_section_title_markup .= '<p>'. esc_html( $sub_title ) .'</p>';
	}
	if (!empty($title)) {
		$insdustry_section_title_markup .= '<'.$title_tags.'>'. esc_html( $title ) .'</'.$title_tags.'>';
	}
	if (!empty($desc)) {
		$insdustry_section_title_markup .= ''. wpautop( esc_html( $desc ) ) .'';
	}
	$insdustry_section_title_markup .= '</div>';
	


	return $insdustry_section_title_markup;
}
add_shortcode( 'insdustry_section_title', 'insdustry_section_title_shortcode' );

//Service box shortcode register

function insdustry_service_box_shortcode($atts, $content = null){
	extract(shortcode_atts(  array(
		'icon_type' => 1, 
		'fa_icon' => 'fa fa-star', 
		'img_icon' => '', 
		'title' => '',  
		'desc' => '', 
	), $atts ));

	


	$insdustry_service_box_markup ='<div class="insdustry_service_box">';

	if ($icon_type == 1) {
		$insdustry_service_box_markup .='
		<div class="service-icon">
			<i class="'. esc_attr( $fa_icon ) .'"></i>
		</div>';
	}else{

		$img_icon_src = wp_get_attachment_image_src( $img_icon, 'thumbnail' );

		$insdustry_service_box_markup .='
		<div class="service-img-icon">
			<img src="'. esc_url( $img_icon_src[0] ) .'" atl="'. esc_html( $title ) .'" />
		</div>';
	}

	if (!empty($title)) {
		$insdustry_service_box_markup .= '<h2>'. esc_html( $title ) .'</h2>';
	}
	if (!empty($desc)) {
		$insdustry_service_box_markup .= ''. wpautop( esc_html( $desc ) ) .'';
	}

	$insdustry_service_box_markup .= '</div>';
	


	return $insdustry_service_box_markup;
}
add_shortcode( 'insdustry_service_box', 'insdustry_service_box_shortcode' );

//Service box 2 shortcode register

function insdustry_service_box_shortcode2($atts, $content = null){
	extract(shortcode_atts(  array(
		'img' => '', 
		'title' => '',  
		'desc' => '', 
		'link' => '', 
	), $atts ));

	


	$insdustry_service_box_markup2 ='<div class="insdustry_service_box_2">';

	
	$img_icon_src = wp_get_attachment_image_src( $img, 'large' );

	$insdustry_service_box_markup2 .='<div class="insdustry-service-img">
		<img src="'. esc_url( $img_icon_src[0] ) .'" atl="'. esc_html( $title ) .'" />
	</div>';

	if (!empty($title)) {
		$insdustry_service_box_markup2 .= '<h2>'. esc_html( $title ) .'</h2>';
	}
	if (!empty($desc)) {
		$insdustry_service_box_markup2 .= ''. wpautop( esc_html( $desc ) ) .'';
	}
	//$insdustry_service_box_markup2 .='<pre>'.var_dump($link).'</pre>';
	if (!empty($link)) {
		$link_array = explode('|', $link);
		$insdustry_service_box_markup2 .= '<a class="boxed-btn" href="'.$link_array[0].'" target="'.$link_array[2].'">'.$link_array[1].'</a>';
	}

	$insdustry_service_box_markup2 .= '</div>';
	


	return $insdustry_service_box_markup2;
}
add_shortcode( 'insdustry_service_box2', 'insdustry_service_box_shortcode2' );

//Service box 3 shortcode register

function insdustry_service_box_shortcode3($atts, $content = null){
	extract(shortcode_atts(  array(
		'icon_type' => 1, 
		'fa_icon' => 'fa fa-star', 
		'img_icon' => '',  
		'title' => '',  
		'desc' => '', 
		'link' => '', 
	), $atts ));

	


	$insdustry_service_box_markup3 ='<div class="insdustry_service_box_3">';

	
	if ($icon_type == 1) {
		$insdustry_service_box_markup3 .='<div class="service-icon">
			<i class="'. esc_attr( $fa_icon ) .'"></i>
		</div>';
	}else{

		$img_icon_src = wp_get_attachment_image_src( $img_icon, 'thumbnail' );

		$insdustry_service_box_markup3 .='<div class="service-img-icon">
			<img src="'. esc_url( $img_icon_src[0] ) .'" atl="'. esc_html( $title ) .'" />
		</div>';
	}


	if (!empty($title)) {
		$insdustry_service_box_markup3 .= '<h2>'. esc_html( $title ) .'</h2>';
	}
	if (!empty($desc)) {
		$insdustry_service_box_markup3 .= ''. wpautop( esc_html( $desc ) ) .'';
	}
	//$insdustry_service_box_markup3 .='<pre>'.var_dump($link).'</pre>';
	if (!empty($link)) {
		$link_array = explode('|', $link);
		$insdustry_service_box_markup3 .= '<a class="inline-btn" href="'.$link_array[0].'" target="'.$link_array[2].'">'.$link_array[1].'<i class="fa fa-caret-right"></i></a>';
	}

	$insdustry_service_box_markup3 .= '</div>';
	


	return $insdustry_service_box_markup3;
}
add_shortcode( 'insdustry_service_box3', 'insdustry_service_box_shortcode3' );

//Service box 2 shortcode register

function insdustry_case_studies_shortcode($atts, $content = null){
	extract(shortcode_atts(  array(
		'img' => '', 
		'title' => '',  
		'desc' => '', 
		'link' => '', 
	), $atts ));

	


	$insdustry_case_studies ='<div class="insdustry_case_studies">';

	
	$img_icon_src = wp_get_attachment_image_src( $img, 'large' );

	$insdustry_case_studies .='<div class="insdustry_case_study_img" style="background-image: url('. esc_url( $img_icon_src[0] ) .')">
	</div>';

	if (!empty($title)) {
		$insdustry_case_studies .= '<h2>'. esc_html( $title ) .'</h2>';
	}
	if (!empty($desc)) {
		$insdustry_case_studies .= ''. wpautop( esc_html( $desc ) ) .'';
	}
	//$insdustry_case_studies .='<pre>'.var_dump($link).'</pre>';
	if (!empty($link)) {
		$link_array = explode('|', $link);
		$insdustry_case_studies .= '<a class="case-study-btn" href="'.$link_array[0].'" target="'.$link_array[2].'">'.$link_array[1].'</a>';
	}

	$insdustry_case_studies .= '</div>';
	


	return $insdustry_case_studies;
}
add_shortcode( 'insdustry_case_study', 'insdustry_case_studies_shortcode' );

//Slide shortcode register

function industry_slider($atts, $content = null){
	extract(shortcode_atts(  array(
		'count' => 3,
		'category' => '',
        'loop'  => 'true',
        'autoplay' => 'false',
        'autoplayTimeout' => '5000',
        'nav'   => 'true',
        'dots'  => 'true',
        'mousedrag' => 'false',
        'height' => '730' 
	), $atts ));

	if(!empty($category)){
		$list = new WP_Query(array(
			'post_type' => 'slide',
			'posts_per_page' => $count,
			'tax_query'		=> array(
				array(
					'taxonomy'		=> 'slide_cat',
					'field'			=> 'term_id',
					'terms'			=> $category,
				)
			)
		));
	}else{

		$list = new WP_Query(array(
			'post_type' => 'slide',
			'posts_per_page' => $count,
		));
	}
	$slider_rand_id = rand(45698, 987456);

	$industry_slider_markup = '

	<script>
		jQuery(window).load(function(){
			jQuery("#industry_slide_'.$slider_rand_id.'").owlCarousel({
				items: 1,
                loop: '.$loop.',
                autoplay: '.$autoplay.',
                autoplayTimeout: '.$autoplayTimeout.',
                nav: '.$nav.',
                dots: '.$dots.',
                mouseDrag: '.$mousedrag.',
                navText: ["<i class=\'fa fa-angle-left\'></i>", "<i class=\'fa fa-angle-right\'></i>"]
			});
			jQuery(".industry_slide_preloader").fadeOut(1000);

		});
	</script>
	<div class="industry_slides_wrapper">
		<div class="industry_slide_preloader">
			<span class="preloader_wrapper">
				<div class="circular-container">
				    <div class="circle circular-loader1">
				      <div class="circle circular-loader2">    
				      </div>
				    </div>
				  </div>
			</span>
		</div>
	
		
	<div id="industry_slide_'.$slider_rand_id.'" class="industry_slides">';

	while($list->have_posts()) : $list->the_post();
	$post_id = get_the_ID();

	if(get_post_meta( get_the_ID(), 'slider_metabox', true )){
		$slider_meta = get_post_meta( get_the_ID(), 'slider_metabox', true );
	}else{
		$slider_meta = array();
	}

	if(array_key_exists('slider_text_color', $slider_meta)) {
		$slider_text_color = $slider_meta['slider_text_color'];
	}else{
		$slider_text_color = '#333';
	}
	if(array_key_exists('width', $slider_meta)) {
		$width = $slider_meta['width'];
	}else{
		$width = 'col-md-6';
	}
	if(array_key_exists('offset', $slider_meta)) {
		$offset = $slider_meta['offset'];
	}else{
		$offset = 'no-offset';
	}
	if(array_key_exists('align', $slider_meta)) {
		$align = $slider_meta['align'];
	}else{
		$align = 'left';
	}
	if(array_key_exists('overlay_enable', $slider_meta)) {
		$overlay_enable = $slider_meta['overlay_enable'];
	}else{
		$overlay_enable = false;
	}
	if(array_key_exists('overlay_opacity', $slider_meta)) {
		$overlay_opacity = $slider_meta['overlay_opacity'];
	}else{
		$overlay_opacity = false;
	}
	if(array_key_exists('overlay_color', $slider_meta)) {
		$overlay_color = $slider_meta['overlay_color'];
	}else{
		$overlay_color = '#333';
	}


	if(array_key_exists('button_enable', $slider_meta)) {
		$button_enable = $slider_meta['button_enable'];
	}else{
		$button_enable = false;
	}
	if(array_key_exists('select_btn', $slider_meta)) {
		$select_btn = $slider_meta['select_btn'];
	}else{
		$select_btn = 'page_link';
	}
	if(array_key_exists('btn_link_page', $slider_meta)) {
		$btn_link_page = $slider_meta['btn_link_page'];
	}else{
		$btn_link_page = array();
	}

	$industry_slider_markup .= '<div style="background-image:url('. get_the_post_thumbnail_url($post_id, 'large') .')" class="industry_single_slider">';
			if($overlay_enable == true){
				$industry_slider_markup .='<div style="opacity:.'.$overlay_opacity.'; background-color:'.$overlay_color.'" class="industry_slider_overlay"></div>';
			}

	$industry_slider_markup .='<div class="industry_single_slider_inner">
				<div class="container">
					<div class="row">
						<div class="'.$width.' '.$offset.' text-'.$align.'" style="color:'. $slider_text_color .'">
							<h2>'. get_the_title( $post_id ) .'</h2>
							'. wpautop( get_the_content( $post_id ) ) .'';
							
							
$industry_slider_markup .='</div>
					</div>
				</div>
			</div>
		</div>';

	endwhile;
	$industry_slider_markup .= '</div></div>';
	wp_reset_query();


	return $industry_slider_markup;
}
add_shortcode( 'industry_slides', 'industry_slider' );


//Counter box shortcode register

function insdustry_counter_box_shortcode($atts, $content = null){
	extract(shortcode_atts(  array(
		'icon_type' => 1, 
		'fa_icon' => 'fa fa-star', 
		'img_icon' => '', 
		'title' => '',  
		'counter_number' => '', 
	), $atts ));

	


	$insdustry_counter_box_markup ='<div class="insdustry_counter_box">';

	if ($icon_type == 1) {
		$insdustry_counter_box_markup .='<div class="counter-icon">
			<i class="'. esc_attr( $fa_icon ) .'"></i>
		</div>';
	}else{

		$img_icon_src = wp_get_attachment_image_src( $img_icon, 'thumbnail' );

		$insdustry_counter_box_markup .='<div class="counter-img-icon">
			<img src="'. esc_url( $img_icon_src[0] ) .'" atl="'. esc_html( $title ) .'" />
		</div>';
	}

	if (!empty($title)) {
		$insdustry_counter_box_markup .= ''. wpautop( esc_html( $title ) ) .'';
	}
	if (!empty($counter_number)) {
		$insdustry_counter_box_markup .= '<h2>'. esc_html( $counter_number ) .'</h2>';
	}

	$insdustry_counter_box_markup .= '</div>';
	


	return $insdustry_counter_box_markup;
}
add_shortcode( 'insdustry_counter_box', 'insdustry_counter_box_shortcode' );


//Social shortcode register

